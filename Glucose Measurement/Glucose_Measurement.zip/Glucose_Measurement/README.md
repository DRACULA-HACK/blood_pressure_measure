# nrf5-gls-context

recoded by Master hack

Support for Glucose Measurement Context on Nordic's Glucose Service.

Place files in ``[SDK_ROOT]\components\ble\ble_services\ble_gls``.

Tested on nrf51822 SDK v12.3.0 SoftDevice s130.
