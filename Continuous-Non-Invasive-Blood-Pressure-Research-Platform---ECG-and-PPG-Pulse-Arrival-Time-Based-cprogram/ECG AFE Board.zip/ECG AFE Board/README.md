# ECG Analog-Front-End Design

two electrode ECG without RLD

![alt text](https://github.com/GCY/Continuous-Non-Invasive-Blood-Pressure-Research-Platform---ECG-and-PPG-Pulse-Arrival-Time-Based-/blob/master/ECG%20AFE%20Board/ECG.jpg)
